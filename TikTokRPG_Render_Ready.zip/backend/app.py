
from flask import Flask, request, jsonify
import random, time

app = Flask(__name__)

character = {
    "name": "Chasseur d’Ombres",
    "class": "Aventurier",
    "level": 1,
    "xp": 0,
    "next_level_xp": 100,
    "hp": 100,
    "max_hp": 100
}

donations = []
top_viewer = {
    "name": "Inconnu",
    "avatar": "https://via.placeholder.com/80",
    "total_xp": 0
}

# Gain d'XP
def add_xp(amount):
    character["xp"] += amount
    while character["xp"] >= character["next_level_xp"]:
        character["xp"] -= character["next_level_xp"]
        character["level"] += 1
        character["next_level_xp"] = int(character["next_level_xp"] * 1.25)
        character["hp"] = character["max_hp"] + character["level"] * 10

@app.route("/donate", methods=["POST"])
def donate():
    data = request.json
    name = data["name"]
    avatar = data["avatar"]
    amount = data["xp"]

    donations.append({"name": name, "avatar": avatar, "xp": amount})
    add_xp(amount)

    # Gestion du top viewer
    matching = [d for d in donations if d["name"] == name]
    total = sum(d["xp"] for d in matching)
    if total > top_viewer["total_xp"]:
        top_viewer.update({
            "name": name,
            "avatar": avatar,
            "total_xp": total
        })

    return jsonify({"status": "ok"})

@app.route("/status", methods=["GET"])
def status():
    return jsonify({
        "character": character,
        "top_viewer": top_viewer
    })

if __name__ == "__main__":
    app.run(debug=True)
