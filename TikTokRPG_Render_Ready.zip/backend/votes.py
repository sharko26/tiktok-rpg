
from flask import Flask, request, jsonify
from collections import Counter

app = Flask(__name__)
votes = []

@app.route("/vote", methods=["POST"])
def vote():
    data = request.json
    choice = data.get("choice")
    if choice:
        votes.append(choice)
        return jsonify({"status": "vote enregistré"})
    return jsonify({"status": "erreur"}), 400

@app.route("/votes", methods=["GET"])
def get_votes():
    count = Counter(votes)
    total = sum(count.values())
    return jsonify({
        "total_votes": total,
        "results": count
    })

@app.route("/reset_votes", methods=["POST"])
def reset_votes():
    votes.clear()
    return jsonify({"status": "votes réinitialisés"})
