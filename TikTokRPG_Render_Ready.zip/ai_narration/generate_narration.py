
import random

def generate_narration(level):
    intros = [
        "Une nouvelle puissance vient d’émerger.",
        "Le souffle de l’ombre se fait plus fort.",
        "Un frisson parcourt l’air, annonçant l’éveil."
    ]
    transitions = [
        f"Notre aventurier atteint le niveau {level}.",
        f"Le niveau {level} est désormais entre ses mains.",
        f"Il franchit un nouveau cap : niveau {level}."
    ]
    conclusions = [
        "Les ennemis tremblent déjà face à cette évolution.",
        "Son regard brille d'une lumière plus intense.",
        "Il n’est plus le même. Il est devenu… plus que redoutable."
    ]
    return f"{random.choice(intros)} {random.choice(transitions)} {random.choice(conclusions)}"

if __name__ == "__main__":
    for lvl in range(1, 5):
        print(generate_narration(lvl))
